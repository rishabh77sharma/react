![Task31](task31.png)
![Task31](task32.png)
https://react-colorpicker-delta.vercel.app/
