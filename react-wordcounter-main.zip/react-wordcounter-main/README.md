![Task1](task1.png)
https://react-wordcounter.vercel.app/
