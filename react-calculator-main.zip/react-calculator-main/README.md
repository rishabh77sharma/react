![Task2](task2.png)
https://react-calculator-iota-orpin.vercel.app/
